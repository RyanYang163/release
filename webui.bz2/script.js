/* ============================================
   Interactive Particle Network Animation
   ============================================ */

const canvas = document.getElementById('particleCanvas');
const ctx = canvas.getContext('2d');

let width, height;
let particles = [];
let mouse = { x: -1000, y: -1000 };
const PARTICLE_COUNT = 100;
const CONNECT_DIST = 150;
const MOUSE_RADIUS = 200;

// Colors
const colors = ['rgba(11,140,230,', 'rgba(139,92,246,', 'rgba(16,185,129,'];

class Particle {
  constructor() {
    this.reset();
    this.y = Math.random() * height; // distribute initially
  }
  reset() {
    this.x = Math.random() * width;
    this.y = Math.random() * height;
    this.vx = (Math.random() - 0.5) * 0.6;
    this.vy = (Math.random() - 0.5) * 0.6;
    this.radius = Math.random() * 2 + 1;
    this.colorIndex = Math.floor(Math.random() * colors.length);
  }
  update() {
    this.x += this.vx;
    this.y += this.vy;
    if (this.x < -50) this.x = width + 50;
    if (this.x > width + 50) this.x = -50;
    if (this.y < -50) this.y = height + 50;
    if (this.y > height + 50) this.y = -50;
  }
  draw(ctx) {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fillStyle = colors[this.colorIndex] + '0.8)';
    ctx.fill();
  }
}

function init() {
  resize();
  particles = [];
  for (let i = 0; i < PARTICLE_COUNT; i++) {
    particles.push(new Particle());
  }
}

function resize() {
  width = window.innerWidth;
  height = window.innerHeight;
  canvas.width = width;
  canvas.height = height;
}

function drawConnections() {
  for (let i = 0; i < particles.length; i++) {
    for (let j = i + 1; j < particles.length; j++) {
      const dx = particles[i].x - particles[j].x;
      const dy = particles[i].y - particles[j].y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < CONNECT_DIST) {
        const opacity = (1 - dist / CONNECT_DIST) * 0.25;
        ctx.beginPath();
        ctx.moveTo(particles[i].x, particles[i].y);
        ctx.lineTo(particles[j].x, particles[j].y);
        ctx.strokeStyle = 'rgba(255,255,255,' + opacity + ')';
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }
    }
  }
}

function drawMouseConnections() {
  for (let i = 0; i < particles.length; i++) {
    const dx = particles[i].x - mouse.x;
    const dy = particles[i].y - mouse.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < MOUSE_RADIUS) {
      // Push particles away from mouse
      const force = (MOUSE_RADIUS - dist) / MOUSE_RADIUS;
      particles[i].vx += (dx / dist) * force * 0.3;
      particles[i].vy += (dy / dist) * force * 0.3;

      // Draw connection to mouse
      const opacity = (1 - dist / MOUSE_RADIUS) * 0.5;
      ctx.beginPath();
      ctx.moveTo(particles[i].x, particles[i].y);
      ctx.lineTo(mouse.x, mouse.y);
      ctx.strokeStyle = colors[particles[i].colorIndex] + opacity + ')';
      ctx.lineWidth = 0.8;
      ctx.stroke();
    }

    // Speed limit
    const speed = Math.sqrt(particles[i].vx * particles[i].vx + particles[i].vy * particles[i].vy);
    if (speed > 2) {
      particles[i].vx = (particles[i].vx / speed) * 2;
      particles[i].vy = (particles[i].vy / speed) * 2;
    }
  }
}

function animate() {
  ctx.clearRect(0, 0, width, height);

  // Update & draw
  for (const p of particles) {
    p.update();
    p.draw(ctx);
  }

  drawConnections();
  drawMouseConnections();

  requestAnimationFrame(animate);
}

// Events
window.addEventListener('resize', resize);
window.addEventListener('mousemove', (e) => {
  mouse.x = e.clientX;
  mouse.y = e.clientY;
});
window.addEventListener('mouseleave', () => {
  mouse.x = -1000;
  mouse.y = -1000;
});

// Touch support
window.addEventListener('touchmove', (e) => {
  mouse.x = e.touches[0].clientX;
  mouse.y = e.touches[0].clientY;
});
window.addEventListener('touchend', () => {
  mouse.x = -1000;
  mouse.y = -1000;
});

// Init
init();
animate();

// 3D tilt effect for cards
document.querySelectorAll('[data-tilt]').forEach(card => {
  card.addEventListener('mousemove', (e) => {
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = ((y - centerY) / centerY) * -5;
    const rotateY = ((x - centerX) / centerX) * 5;
    card.style.transform = `translateY(-6px) perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
  });
  card.addEventListener('mouseleave', () => {
    card.style.transform = '';
  });
});
